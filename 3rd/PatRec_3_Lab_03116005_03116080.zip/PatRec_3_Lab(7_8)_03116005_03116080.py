#!/usr/bin/env python
# coding: utf-8

# ## Αναγνώριση Προτύπων
# 
# ### 3ο εργαστήριο
# 
# ### Αριστοτέλης-Γεώργιος Συμπέθερος  Α.Μ.:03116005
# ### Σάββας Σιφναίος Α.Μ.:03116080 

# In[1]:


# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python Docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)

# Input data files are available in the read-only "../input/" directory
# For example, running this (by clicking run or pressing Shift+Enter) will list all files under the input directory

import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))

# You can write up to 20GB to the current directory (/kaggle/working/) that gets preserved as output when you create a version using "Save & Run All" 
# You can also write temporary files to /kaggle/temp/, but they won't be saved outside of the current session


# ### Βήμα 1

# ### (α)

# In[2]:


import re
#Get all labels
f = open('../input/patreco3-multitask-affective-music/data/fma_genre_spectrograms/train_labels.txt', "r")
labels=list(f)
labels=[ re.split(r'\t+', i.rstrip('\t')) for i in labels]
labels=[[i[0],i[1].split('\n')[0]] for i in labels]


# In[3]:


#Get 2 Random Samples from dataset (which are note the same music type)
spec_1 = np.load('/kaggle/input/patreco3-multitask-affective-music/data/fma_genre_spectrograms/train/1042.fused.full.npy')
spec_2 = np.load('/kaggle/input/patreco3-multitask-affective-music/data/fma_genre_spectrograms/train/115357.fused.full.npy')


# In[4]:


print(spec_1.shape)  # (frequencies x time steps)
print(spec_2.shape)  # (frequencies x time steps)
lbl_1=[i [1] for i in labels if i[0]=="1042.fused.full.npy.gz"][0]
lbl_2=[i [1] for i in labels if i[0]=="115357.fused.full.npy.gz"][0]

print(f"Sample 1 is of type: {lbl_1}")
print(f"Sample 2 is of type: {lbl_2}")


# In[5]:


#Get mel (and chroma for (c)) 
mel_1, chroma_1 = spec_1[:128], spec_1[128:]
mel_2, chroma_2 = spec_2[:128], spec_2[128:]


# In[6]:


# Plot the spectrogram
import librosa.display
import matplotlib.pyplot as plt


fig, (ax1,ax2) = plt.subplots(1, 2, figsize=(14, 5))
img = librosa.display.specshow(mel_1, x_axis='time', y_axis='linear', ax=ax1)
ax1.set(title=f'Spectrogram of random {lbl_1} sample')
fig.colorbar(img, ax=ax1, format="%+2.f dB")

img = librosa.display.specshow(mel_2, x_axis='time', y_axis='linear', ax=ax2)
ax2.set(title=f'Spectrogram of random {lbl_2} sample')
fig.colorbar(img, ax=ax2, format="%+2.f dB")


# ### Βήμα 2

# In[7]:


print(mel_1.shape)
print(mel_2.shape)


# Έχουν 1293 χρονικά βήματα.Το παραπάνω δεν ειναι αποδοτικό καθώς ειναι υπερβολικά μεγάλος αριθμός βημάτων (εκτός απο θέματα απόδοσης και εκπαίδευσης) το LSTM αν και καλύτερο απο το RNN στο θέμα αυτό , θα υποφέρει απο το vanishing gradient καθώς δεν θα μπορεί να συγκρατεί πληροφορία απο χρονικά βήματα πολυ νωρίτερα.

# In[8]:


#Get labels for beat synched
f = open('../input/patreco3-multitask-affective-music/data/fma_genre_spectrograms_beat/train_labels.txt', "r")
labels_beat=list(f)
labels_beat=[ re.split(r'\t+', i.rstrip('\t')) for i in labels_beat]
labels_beat=[[i[0],i[1].split('\n')[0]] for i in labels_beat]


# In[9]:


#Get all names and data
specs_list=[]
specs_names=[]
for dirname, _, filenames in os.walk('/kaggle/input/patreco3-multitask-affective-music/data/fma_genre_spectrograms_beat/train/'):
    for filename in filenames:
        specs_names.append(filename)
        specs_list.append(np.load('../input/patreco3-multitask-affective-music/data/fma_genre_spectrograms_beat/train/'+filename))       


# In[10]:


idx1=1358
idx2=1961
spec_1_beat =specs_list[idx1]
spec_2_beat =specs_list[idx2]

#Finding corresponding indexes
# for i in range(len(specs_names)):
#     if specs_names[i].split('.')[0]=='115357':
#         print(i)    


# In[11]:


print(spec_1_beat.shape)  
print(spec_2_beat.shape)  
lbl_1_beat=[i[1] for i in labels_beat[1:] if i[0].split('.')[0]==specs_names[idx1].split('.')[0]][0]
lbl_2_beat=[i[1] for i in labels_beat[1:] if i[0].split('.')[0]==specs_names[idx2].split('.')[0]][0]
print(f"Sample 1 is of type: {lbl_1_beat}")
print(f"Sample 2 is of type: {lbl_2_beat}")


# Τα χρονικά βήματα μειώθηκαν σε 62 για τα παραδειγμά μας , αριθμό εξαιρετικά μικρότερο απο ότι προηγουμένως.

# In[12]:


#Find maximum time steps in all data instances and calculate the mean of time steps.
max_shape=0
mean_shape=0
for i in range(len(specs_list)):
    mean_shape+=specs_list[i].shape[1]
    if specs_list[i].shape[1]>max_shape:
        max_shape=specs_list[i].shape[1]
print(f"Maximum number of time steps found: {max_shape}")
print(f"Mean number of time steps : {mean_shape/len(specs_list)}")


# In[13]:


mel_1_beat, chroma_1_beat = spec_1_beat[:128], spec_1_beat[128:]
mel_2_beat, chroma_2_beat = spec_2_beat[:128], spec_2_beat[128:]


# In[14]:


print(mel_1_beat.shape)  
print(mel_2_beat.shape) 


# In[15]:


#Spectrogramms plots for beat synched data

fig, (ax1,ax2) = plt.subplots(1, 2, figsize=(14, 5))
img = librosa.display.specshow(mel_1_beat, x_axis='time', y_axis='linear', ax=ax1)
ax1.set(title=f'Spectrogram of random {lbl_1_beat} sample')
fig.colorbar(img, ax=ax1, format="%+2.f dB")


img = librosa.display.specshow(mel_2_beat, x_axis='time', y_axis='linear', ax=ax2)
ax2.set(title=f'Spectrogram of random {lbl_2_beat} sample')
fig.colorbar(img, ax=ax2, format="%+2.f dB")


# Βλέπουμε πως τα δεδομένα είναι πιο "διακριτά" ως προς τον άξονα το χρόνουν το οποίο είναι αναμενόμενο ,ωστόσο βλέπουε οτι αν και εξαιρετικά λιγότερα δείγματα οι γραφικές μας δείχνουν παρόμοια πληροφορία.

# #### Χρωμογραφήματα

# Έχουμε ήδη κρατήσει απο προηγουμένως τις τιμές για χρωμογραφήματα καθώς διαβάζαμε το data.Τα χρονικά βήματα είναι ίδια όπως δείξαμε παραπάνω (και φαίνεται ξανα παρακάτω).Ωστόσο πλέον στις αντίστοιχες συχνότητες έχουμε 12 διαφορετικές νότες (ημιτόνια) (Παραπάνω πληροφορίες στην αναφορά).

# In[16]:


print(chroma_1.shape)
print(chroma_1.shape)
print(chroma_1_beat.shape)  
print(chroma_1_beat.shape)  


# In[17]:


fig, ax = plt.subplots(2, 2, figsize=(15, 10))


img = librosa.display.specshow(chroma_1, y_axis='chroma', x_axis='time', ax=ax[0,0])
ax[0,0].set(title=f'Chromagram of random {lbl_1} sample')
fig.colorbar(img, ax=ax[0,0])

img = librosa.display.specshow(chroma_2, y_axis='chroma', x_axis='time', ax=ax[0,1])
ax[0,1].set(title=f'Chromagram of random {lbl_2} sample')
fig.colorbar(img, ax=ax[0,1])


img = librosa.display.specshow(chroma_1_beat, y_axis='chroma', x_axis='time', ax=ax[1,0])
ax[1,0].set(title=f'Chromagram of random {lbl_1_beat} (on beat) sample')
fig.colorbar(img, ax=ax[1,0])


img = librosa.display.specshow(chroma_2_beat, y_axis='chroma', x_axis='time', ax=ax[1,1])
ax[1,1].set(title=f'Chromagram of random {lbl_2_beat} (on beat) sample')
fig.colorbar(img, ax=ax[1,1])


# ### Βήμα 4

# (b)

# In[18]:


labels_for_hist=[i[1].split('\n')[0] for i in labels_beat[1:]]
class_counting = {
    'Rock': 0,
    'Psych-Rock': 0,
    'Indie-Rock':0,
    'Post-Rock': 0,
    'Psych-Folk': 0,
    'Folk': 0,
    'Metal': 0,
    'Punk': 0,
    'Post-Punk': 0,
    'Trip-Hop': 0,
    'Pop': 0,
    'Electronic': 0,
    'Hip-Hop': 0,
    'Classical': 0,
    'Blues': 0,
    'Chiptune': 0,
    'Jazz': 0,
    'Soundtrack': 0,
    'International':0,
    'Old-Time': 0
}

class_counting_after = {
    'Rock': 0,
    'Psych-Rock': 0,
    'Indie-Rock':0,
    'Post-Rock': 0,
    'Psych-Folk': 0,
    'Folk': 0,
    'Metal': 0,
    'Punk': 0,
    'Post-Punk': 0,
    'Trip-Hop': 0,
    'Pop': 0,
    'Electronic': 0,
    'Hip-Hop': 0,
    'Classical': 0,
    'Blues': 0,
    'Chiptune': 0,
    'Jazz': 0,
    'Soundtrack': 0,
    'International':0,
    'Old-Time': 0
}

class_mapping = {
    'Rock': 'Rock',
    'Psych-Rock': 'Rock',
    'Indie-Rock': None,
    'Post-Rock': 'Rock',
    'Psych-Folk': 'Folk',
    'Folk': 'Folk',
    'Metal': 'Metal',
    'Punk': 'Metal',
    'Post-Punk': None,
    'Trip-Hop': 'Trip-Hop',
    'Pop': 'Pop',
    'Electronic': 'Electronic',
    'Hip-Hop': 'Hip-Hop',
    'Classical': 'Classical',
    'Blues': 'Blues',
    'Chiptune': 'Electronic',
    'Jazz': 'Jazz',
    'Soundtrack': None,
    'International': None,
    'Old-Time': None
}

for label in labels_for_hist:
    class_counting[label]+=1


for label in labels_for_hist:
    if (class_mapping[label]==None):
        continue
    else:
        class_counting_after[class_mapping[label]]+=1


# ###  (c)

# In[19]:


print(class_counting)

plt.figure(figsize=(30,6))
plt.bar(class_counting.keys(),class_counting.values())
plt.title("Genres before mapping")


# In[20]:


print(class_counting_after)

plt.figure(figsize=(30,6))
x_bar,y_bar=[],[]
for key in class_counting_after.keys():
    if (class_counting_after[key]==0):
        continue
    else:
        x_bar.append(key)
        y_bar.append(class_counting_after[key])
        
plt.bar(x_bar,y_bar)
plt.title("Genres after mapping")


# In[21]:


# Import the necessary libraries
import numpy as np
import copy
from sklearn.preprocessing import LabelEncoder
from torch.utils.data import Dataset
from torch.utils.data import SubsetRandomSampler, DataLoader
import re

# Combine similar classes and remove underrepresented classes
class_mapping = {
    'Rock': 'Rock',
    'Psych-Rock': 'Rock',
    'Indie-Rock': None,
    'Post-Rock': 'Rock',
    'Psych-Folk': 'Folk',
    'Folk': 'Folk',
    'Metal': 'Metal',
    'Punk': 'Metal',
    'Post-Punk': None,
    'Trip-Hop': 'Trip-Hop',
    'Pop': 'Pop',
    'Electronic': 'Electronic',
    'Hip-Hop': 'Hip-Hop',
    'Classical': 'Classical',
    'Blues': 'Blues',
    'Chiptune': 'Electronic',
    'Jazz': 'Jazz',
    'Soundtrack': None,
    'International': None,
    'Old-Time': None
}

# Helper functions to read fused, mel, and chromagram
def read_fused_spectrogram(spectrogram_file):
    spectrogram = np.load(spectrogram_file)
    return spectrogram.T


def read_mel_spectrogram(spectrogram_file):
    spectrogram = np.load(spectrogram_file)[:128]
    return spectrogram.T

def read_chromagram(spectrogram_file):
    spectrogram = np.load(spectrogram_file)[128:]
    return spectrogram.T


# In[22]:


# TODO: It's useful to set the seed when debugging but when experimenting ALWAYS set seed=None. Why?

#For experimenting seed gives us always the same split in train,val (or test) sets of the data.
#We should never use seed to train and optimize our NN because we are working with a specific split and not random and thus optimizing
#on the specific problem (split) we made. This will have as result bad generalization of our model!
def torch_train_val_split(dataset, batch_train, batch_eval,val_size=.2,test_size=.0, shuffle=True, seed=None,overfitt_test=False):
    # Creating data indices for training and validation splits:
    dataset_size = len(dataset)
    if overfitt_test:
        dataset_size = 30
    
    #Get indexes for whole dataset
    indices = list(range(dataset_size))
    #Get number of indexes corresponding for validation set size
    val_split = int(np.floor(val_size * dataset_size))
    if test_size>0:
        #Get number of indexes corresponding for test set size (only for multitask problem and if test_size>0)
        test_split=int(np.floor(test_size * dataset_size))
    
    #Shuffle all the above indexes
    if shuffle:
        np.random.seed(seed)
        np.random.shuffle(indices)
    #Get corresponding number of indices for validation set from the random shuffle
    train_indices = indices[val_split:]
    #Get corresponding number of indices (the rest of them) for train set from the random shuffle
    val_indices = indices[:val_split]
    
    if test_size>0:
        #Special case, get corresponding number of indices for train,validation and test set from the random shuffle
        train_indices = indices[test_split+val_split:]
        val_indices = indices[test_split:test_split+val_split]
        test_indices = indices[:test_split]

        
    # Creating PT data samplers and loaders:
    train_sampler = SubsetRandomSampler(train_indices)
    val_sampler = SubsetRandomSampler(val_indices)
    if test_size>0:
        test_sampler = SubsetRandomSampler(test_indices)
    
    #Creating Dataloaders for each set 
    
    train_loader = DataLoader(dataset,
                              batch_size=batch_train,
                              sampler=train_sampler)
    val_loader = DataLoader(dataset,
                            batch_size=batch_eval,
                            sampler=val_sampler)
    
    if test_size>0:    
        test_loader = DataLoader(dataset,
                            batch_size=batch_eval,
                            sampler=test_sampler)
        
        return train_loader, val_loader,test_loader
    else:
        return train_loader, val_loader


class LabelTransformer(LabelEncoder):
    def inverse(self, y):
        try:
            return super(LabelTransformer, self).inverse_transform(y)
        except:
            return super(LabelTransformer, self).inverse_transform([y])

    def transform(self, y):
        try:
            return super(LabelTransformer, self).transform(y)
        except:
            return super(LabelTransformer, self).transform([y])


# TODO: Comment on why padding is needed (done in report)
class PaddingTransform(object):
    def __init__(self, max_length, padding_value=0):
        self.max_length = max_length
        self.padding_value = padding_value

    def __call__(self, s):
        if len(s) == self.max_length:
            return s

        if len(s) > self.max_length:
            return s[:self.max_length]

        if len(s) < self.max_length:
            s1 = copy.deepcopy(s)
            pad = np.zeros((self.max_length - s.shape[0], s.shape[1]), dtype=np.float32)
            s1 = np.vstack((s1, pad))
            return s1

# Pytorch Dataset Class for creating the dataset
class SpectrogramDataset(Dataset):
    def __init__(self, path, class_mapping=None, train=True, max_length=-1, read_spec_fn=read_fused_spectrogram,multi=(False,1),size=(1,1)):
        t = 'train' if train else 'test'
        p = os.path.join(path, t)
        self.index = os.path.join(path, "{}_labels.txt".format(t))
        self.files, labels = self.get_files_labels(self.index, class_mapping,multi)
        self.feats = [read_spec_fn(os.path.join(p, f)) for f in self.files]
        
        if t=='test' and size!=(1,1):
            tmp_list=[]            
            for f in self.feats:
                size_0=f.shape[0]
                target = np.zeros(size)
                target[:size_0,:]=f
                tmp_list.append(target)
            
            self.feats = tmp_list
        
        self.feat_dim = self.feats[0].shape[1]
        self.lengths = [len(i) for i in self.feats]
        self.max_length = max(self.lengths) if max_length <= 0 else max_length
        self.zero_pad_and_stack = PaddingTransform(self.max_length)
        self.label_transformer = LabelTransformer()
        if multi[0]:
            self.labels=np.array(labels)    
        else:
            if isinstance(labels, (list, tuple)):
                self.labels = np.array(self.label_transformer.fit_transform(labels)).astype('int64')

    def get_files_labels(self, txt, class_mapping,multi):
        with open(txt, 'r') as fd:
            if multi[0]:
                lines = [l.rstrip().split('\t')[0].split(',') for l in fd.readlines()[1:]]
            else:
                lines = [l.rstrip().split('\t') for l in fd.readlines()[1:]]
        files, labels = [], []

        for l in lines:
            label = l[multi[1]]
            if multi[1]==4:
                label = [l[1],l[2],l[3]]    
            if class_mapping:
                label = class_mapping[l[1]]
            if not label:
                continue
            # Kaggle automatically unzips the npy.gz format so this hack is needed
            _id = l[0].split('.')[0]
            npy_file = '{}.fused.full.npy'.format(_id)
            files.append(npy_file)
            labels.append(label)
        return files, labels

    def __getitem__(self, item):        
        l = min(self.lengths[item], self.max_length)
        return self.zero_pad_and_stack(self.feats[item]), self.labels[item], l

    def __len__(self):
        return len(self.labels)


# In[23]:


mel_specs = SpectrogramDataset(
         '../input/patreco3-multitask-affective-music/data/fma_genre_spectrograms/',
         train=True,
         class_mapping=class_mapping,
         max_length=-1,
         read_spec_fn=read_mel_spectrogram)
    
train_loader_mel , val_loader_mel = torch_train_val_split(mel_specs, 32 ,32, val_size=.33)
     
ttest_loader_mel = SpectrogramDataset(
         '../input/patreco3-multitask-affective-music/data/fma_genre_spectrograms/',
         train=False,
         class_mapping=class_mapping,
         max_length=-1,
         read_spec_fn=read_mel_spectrogram,size=(1293,128))

test_loader_mel, _ = torch_train_val_split(ttest_loader_mel, 32 ,32, val_size=0)

#Small Dataloader for training until overfitt to check that our NN works properly
train_loader_mel_overfitt, _ = torch_train_val_split(mel_specs, 32 ,32, val_size=0.99)


# In[24]:


#Get batch
datum_dataloader = next(iter(mel_specs))
print(datum_dataloader)
print(len(datum_dataloader[0]))


# Επιστρέφετε τα δεδομένα για ένα δείγμα,το label του καθώς και το μέγεθος (χρονικά βήματα). 

# In[25]:


#Get batch
datum = next(iter(train_loader_mel))
print('Data shape')
print(datum[0].shape)  # shape of data
print('Labels')
print(datum[1])  # labels in batch
print('Lengths')
print(datum[2])  # length of each element in batch


# In[26]:


from sklearn.metrics import accuracy_score
from tqdm import tqdm
from time import time
import torch
import torch.tensor as tensor
import torch.nn as nn 
from torch.autograd import Variable
from torch.nn import Linear, ReLU, CrossEntropyLoss, Sequential, Conv2d, MaxPool2d, Module, Softmax, BatchNorm2d, Dropout
from torch.optim import Adam, SGD
import torch.nn.functional as F
from sklearn.metrics import f1_score, accuracy_score, recall_score, classification_report


# In[27]:


#For GPU usage
global DEVICE
DEVICE = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
print(DEVICE)


# In[28]:


class BasicLSTM(nn.Module):
    def __init__(self, input_dim, rnn_size, output_dim, num_layers, bidirectional=False,dropout = 0):
        super(BasicLSTM, self).__init__()
        self.bidirectional = bidirectional
        self.feature_size = rnn_size * 2 if self.bidirectional else rnn_size
        self.layers = num_layers
        self.hidden_size = rnn_size
        device=DEVICE
        self.lstm = nn.LSTM(input_size=input_dim,hidden_size=rnn_size,num_layers=num_layers,dropout=dropout,bidirectional=bidirectional,batch_first=True).to(device)
        
        
        self.clf = nn.Linear(in_features=self.feature_size,out_features=output_dim).to(device)
        # --------------- Insert your code here ---------------- #
        # Initialize the LSTM, Dropout, Output layers
    def forward(self, x, lengths):
        """
            x : 3D numpy array of dimension N x L x D
                N: batch index
                L: sequence index
                D: feature index
            lengths: N x 1
         """
        self.DEVICE = 'cuda' if torch.cuda.is_available() else 'cpu'
        DEVICE = self.DEVICE

        # Initial Hidden State h_0
        if self.bidirectional:
            h_0 = torch.zeros(self.layers*2,len(x),self.hidden_size).to(DEVICE).double()
            # Initial Cell State c_0 (same as h_0)
            c_0 = torch.zeros(self.layers*2,len(x),self.hidden_size).to(DEVICE).double()
        else:
            h_0 = torch.zeros(self.layers,len(x),self.hidden_size).to(DEVICE).double()
            # Initial Cell State c_0 (same as h_0)
            c_0 = torch.zeros(self.layers,len(x),self.hidden_size).to(DEVICE).double()
        
        lstm_out,_ = self.lstm(x.double(),(h_0,c_0))
        last_outputs = self.clf(self.last_timestep(lstm_out,lengths,bidirectional=self.bidirectional))
        
        return last_outputs
    
    def last_timestep(self, outputs, lengths, bidirectional=False):
        """
            Returns the last output of the LSTM taking into account the zero padding
        """
        if bidirectional:
            forward, backward = self.split_directions(outputs)
            last_forward = self.last_by_index(forward, lengths)
            last_backward = backward[:, 0, :]
            # Concatenate and return - maybe add more functionalities like average
            return torch.cat((last_forward, last_backward), dim=-1)
        else:
            return self.last_by_index(outputs, lengths)
    @staticmethod
    def split_directions(outputs):
        direction_size = int(outputs.size(-1) / 2)
        forward = outputs[:, :, :direction_size]
        backward = outputs[:, :, direction_size:]
        return forward, backward
    @staticmethod
    def last_by_index(outputs, lengths):
        # Index of the last output for each sequence.
        idx = (lengths - 1).view(-1, 1).expand(outputs.size(0),
                                               outputs.size(2)).unsqueeze(1)
        return outputs.gather(1, idx.long()).squeeze()


# In[29]:


from torch.optim import SGD,Adam,SparseAdam,ASGD
from time import time 
import copy
device=DEVICE
def fit_lstm(model,epochs,lr,t_loader,v_loader,val=True,DEVICE=torch.device('cpu')):
    # Create model and convert to a cuda compatible oject
    model = model.double().to(DEVICE)
    
    to_print=1
    if epochs>100:
        to_print=50
    if epochs>700:
        to_print=100
    
    val_losses = []
    train_losses = []

    # Initialization of loss function and optimizer 
    loss_fun = nn.CrossEntropyLoss()
    optimizer = Adam(model.parameters(),lr=lr)

    for epoch in range(epochs):
        ep_loss = 0             
        # Iterate over batches of the Train Dataset
        model.train()

        for batch in t_loader:
            X,labels,lengths=batch
#             model.zero_grad()
            optimizer.zero_grad()

            out = model(X.to(DEVICE),lengths.to(DEVICE)).to(DEVICE)

            loss = loss_fun(out,labels.to(DEVICE))
            loss.backward()

            optimizer.step()

            ep_loss += loss.data.item()

        train_losses.append(ep_loss/len(t_loader))

        if epoch%to_print == 0:
            print(f'Epoch {epoch+1} : Train loss is {ep_loss/len(t_loader)}')

        model.eval()

        if val :
            with torch.no_grad():
                validation_loss = 0 
                # Iterate over validation set in batches, to check to validation loss
                for i,batch in enumerate(v_loader) :
                    X,labels,lengths=batch

                    out_val = model(X.to(device),lengths.to(device)).to(DEVICE)

                    loss  = loss_fun(out_val.to(DEVICE),labels.to(DEVICE))

                    validation_loss+=loss.data.item()

                val_losses.append(validation_loss/len(v_loader))
                
                if epoch%to_print == 0:
                    print(f'Epoch {epoch+1} : Validation Loss is {validation_loss/len(v_loader)}')
                    print('-'*80)
                    
    if val:
        return model ,train_losses,val_losses
    else :
        return model,train_losses


# In[30]:


# Definition of a function that calculates the accuracy of a model 
def score_lstm(model,loader,DEVICE=torch.device('cpu')) :
    preds = []
    y_test = []
    for i,batch in enumerate(loader,1) :
        X,labels,lengths=batch        
        X.to(DEVICE)
        with torch.no_grad():
            
            out = model(X.to(DEVICE).double(),lengths.to(DEVICE)).to(DEVICE)
        if X.size()[0] !=1 :
            for y_pred,label in zip(out,labels) :
                tmp = torch.argmax(y_pred)
                preds.append(tmp.item())
                y_test.append(label)
        else :
            y_pred = torch.argmax(out).item()
            preds.append(y_pred)
            y_test.append(labels)
    return accuracy_score(preds,y_test),np.array(preds),np.array(y_test)


# In[31]:


model_overfitt = BasicLSTM(128, 16, 10, 1, bidirectional=True)


# In[32]:


start=time()
out = fit_lstm(model_overfitt,epochs=1000,lr=0.001,t_loader=train_loader_mel_overfitt,v_loader=val_loader_mel,val=False,DEVICE=DEVICE)
print(f"Model trained in :{np.round(time()-start,3)}")


# In[33]:


torch.save(model_overfitt, './mel_overfitt')
# model_overfitt=torch.load('../input/models-trained/mel_overfitt',map_location=torch.device('cpu'))


# In[34]:


print(f"Overfitt proof is :{score_lstm(model_overfitt,train_loader_mel_overfitt,DEVICE)}")


# Το μοντέλο μας όπου φαίνεται παραπάνω όντως οδηγήθηκε σε overfitting συνεπώς υπάρχει εκπαίδευση.

# #### Mel dataset

# In[35]:


start=time()
model_mel = BasicLSTM(128, 16, 10, 1, bidirectional=True)
out = fit_lstm(model_mel,epochs=400,lr=0.001,t_loader=train_loader_mel,v_loader=val_loader_mel,val=True,DEVICE=DEVICE)
print(f"Model trained in :{np.round(time()-start,3)} s")


# In[36]:


torch.save(model_overfitt, './mel_rnn_32_ep_400_lr_001')


# In[37]:


score,y_test_pred,y_test=score_lstm(model_mel,test_loader_mel,DEVICE)
print(f"FMA spectrogramms score is :{score} \n")
print(classification_report(y_test, y_test_pred))


# In[38]:


beat_mel_specs = SpectrogramDataset(
         '../input/patreco3-multitask-affective-music/data/fma_genre_spectrograms_beat/',
         train=True,
         class_mapping=class_mapping,
         max_length=-1,
         read_spec_fn=read_mel_spectrogram)
    
train_loader_beat_mel, val_loader_beat_mel = torch_train_val_split(beat_mel_specs, 32 ,32, val_size=.33)
     
ttest_loader_beat_mel = SpectrogramDataset(
         '../input/patreco3-multitask-affective-music/data/fma_genre_spectrograms_beat/',
         train=False,
         class_mapping=class_mapping,
         max_length=-1,
         read_spec_fn=read_mel_spectrogram)

test_loader_beat_mel, _ = torch_train_val_split(ttest_loader_beat_mel, 32 ,32, val_size=0)


# #### Mel beat-synced dataset

# In[39]:


start=time()
model_mel_beat = BasicLSTM(128, 16, 10, 1, bidirectional=True)
out = fit_lstm(model_mel_beat,epochs=500,lr=0.001,t_loader=train_loader_beat_mel,v_loader=val_loader_beat_mel,val=True,DEVICE=DEVICE)
print(f"Model (beat synced) trained in :{np.round(time()-start,3)} s")


# Παρατηρούμε πως η εκπαίδευση γίνεται εξαιρετικά πιο γρήγορα σε σχέση με προηγουμένως. Το οποίο ήταν αναμενόμενο καθώς έχουμε πολύ λιγότερες διαστάσεις.

# In[40]:


torch.save(model_mel_beat, './mel_beat_rnn_32_ep_500_lr_001')


# In[41]:


score,y_test_pred,y_test=score_lstm(model_mel_beat,test_loader_beat_mel,DEVICE)
print(f"FMA spectrogramms Beat synced score is :{score} \n")
print(classification_report(y_test, y_test_pred))


# In[42]:


beat_chroma = SpectrogramDataset(
         '../input/patreco3-multitask-affective-music/data/fma_genre_spectrograms_beat/',
         train=True,
         class_mapping=class_mapping,
         max_length=-1,
         read_spec_fn=read_chromagram)
    
train_loader_beat_chroma, val_loader_beat_chroma = torch_train_val_split(beat_chroma, 32 ,32, val_size=.33)
     
ttest_loader_beat_chroma = SpectrogramDataset(
         '../input/patreco3-multitask-affective-music/data/fma_genre_spectrograms_beat/',
         train=False,
         class_mapping=class_mapping,
         max_length=-1,
         read_spec_fn=read_chromagram)

test_loader_beat_chroma, _ = torch_train_val_split(ttest_loader_beat_chroma, 32 ,32, val_size=0)


# #### Chroma beat-synced dataset

# In[43]:


start=time()
model_chroma_beat = BasicLSTM(12, 16, 10, 1, bidirectional=True)
out = fit_lstm(model_chroma_beat,epochs=400,lr=0.001,t_loader=train_loader_beat_chroma,v_loader=val_loader_beat_chroma,val=True,DEVICE=DEVICE)
print(f"Model (beat synced) trained in :{np.round(time()-start,3)} s")


# In[44]:


torch.save(model_chroma_beat, './chroma_beat_rnn_32_ep_400_lr_001')


# In[45]:


score,y_test_pred,y_test=score_lstm(model_chroma_beat,test_loader_beat_chroma,DEVICE)
print(f"FMA Chromogramm (beat synced) score is :{score}")
print(classification_report(y_test, y_test_pred))


# In[46]:


specs_fused_beat = SpectrogramDataset(
         '../input/patreco3-multitask-affective-music/data/fma_genre_spectrograms_beat/',
         train=True,
         class_mapping=class_mapping,
         max_length=-1,
         read_spec_fn=read_fused_spectrogram)

train_loader_beat, val_loader_beat = torch_train_val_split(specs_fused_beat, 32 ,32, val_size=.33)

ttest_loader_beat = SpectrogramDataset(
     '../input/patreco3-multitask-affective-music/data/fma_genre_spectrograms_beat/',
     train=False,
     class_mapping=class_mapping,
     max_length=-1,
     read_spec_fn=read_fused_spectrogram)


test_loader_beat, _ = torch_train_val_split(ttest_loader_beat, 32 ,32, val_size=0)


# #### Fused (mel & chroma) beat-synced dataset 

# In[47]:


start=time()
model_fused_beat = BasicLSTM(12+128, 16, 10, 1, bidirectional=True)
out = fit_lstm(model_fused_beat,epochs=400,lr=0.001,t_loader=train_loader_beat,v_loader=val_loader_beat,val=True,DEVICE=DEVICE)
print(f"Model (beat synced) trained in :{np.round(time()-start,3)} s")


# In[48]:


torch.save(model_fused_beat, './fused_beat_rnn_32_ep_400_lr_001')


# In[49]:


score,y_test_pred,y_test=score_lstm(model_fused_beat,test_loader_beat,DEVICE)
print(f"Fused (beat synch) score is :{score}")
print(classification_report(y_test, y_test_pred))


# #### Fused dataset 

# In[50]:


specs_fused = SpectrogramDataset(
         '../input/patreco3-multitask-affective-music/data/fma_genre_spectrograms/',
         train=True,
         class_mapping=class_mapping,
         max_length=-1,
         read_spec_fn=read_fused_spectrogram)

train_loader, val_loader = torch_train_val_split(specs_fused, 32 ,32, val_size=.33)

ttest_loader = SpectrogramDataset(
     '../input/patreco3-multitask-affective-music/data/fma_genre_spectrograms/',
     train=False,
     class_mapping=class_mapping,
     max_length=-1,
     read_spec_fn=read_fused_spectrogram)


test_loader, _ = torch_train_val_split(ttest_loader, 32 ,32, val_size=0)


# In[51]:


start=time()
model_fused = BasicLSTM(12+128, 16, 10, 2, bidirectional=True)
out = fit_lstm(model_fused,epochs=500,lr=0.001,t_loader=train_loader,v_loader=val_loader,val=True,DEVICE=DEVICE)
print(f"Model trained in :{np.round(time()-start,3)} s")


# In[52]:


torch.save(model_fused, './fused_rnn_32_ep_400_lr_001')


# In[53]:


score,y_test_pred,y_test=score_lstm(model_fused,test_loader,DEVICE)
print(f"Fused score is :{score}")
print(classification_report(y_test, y_test_pred))

