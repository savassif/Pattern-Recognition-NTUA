#!/usr/bin/env python
# coding: utf-8

# In[1]:


# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python Docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)

# Input data files are available in the read-only "../input/" directory
# For example, running this (by clicking run or pressing Shift+Enter) will list all files under the input directory

import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))

# You can write up to 20GB to the current directory (/kaggle/working/) that gets preserved as output when you create a version using "Save & Run All" 
# You can also write temporary files to /kaggle/temp/, but they won't be saved outside of the current session


# Ο παρακάτω κώδικας είναι επανάληψη του μέρους της προπαρασκευής. Η αλλαγή notebook/kernel έγινε για λόγους μνήμης όπως μάλιστα υποδεικνύεται.

# In[2]:


from sklearn.metrics import accuracy_score
from tqdm import tqdm
from time import time
import torch
import torch.tensor as tensor
import torch.nn as nn 
from torch.autograd import Variable
from torch.nn import Linear, ReLU, CrossEntropyLoss, Sequential, Conv2d, MaxPool2d, Module, Softmax, BatchNorm2d, Dropout,Dropout2d
from torch.optim import Adam, SGD
import torch.nn.functional as F
from sklearn.metrics import f1_score, accuracy_score, recall_score, classification_report
from scipy.stats import spearmanr


# In[3]:


#For GPU usage
global DEVICE
DEVICE = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
print(DEVICE)


# In[4]:


# Import the necessary libraries

import numpy as np
import copy
from sklearn.preprocessing import LabelEncoder
from imblearn.over_sampling import RandomOverSampler
from torch.utils.data import Dataset
from torch.utils.data import SubsetRandomSampler, DataLoader
from sklearn.decomposition import PCA
import re

# Combine similar classes and remove underrepresented classes
class_mapping = {
    'Rock': 'Rock',
    'Psych-Rock': 'Rock',
    'Indie-Rock': None,
    'Post-Rock': 'Rock',
    'Psych-Folk': 'Folk',
    'Folk': 'Folk',
    'Metal': 'Metal',
    'Punk': 'Metal',
    'Post-Punk': None,
    'Trip-Hop': 'Trip-Hop',
    'Pop': 'Pop',
    'Electronic': 'Electronic',
    'Hip-Hop': 'Hip-Hop',
    'Classical': 'Classical',
    'Blues': 'Blues',
    'Chiptune': 'Electronic',
    'Jazz': 'Jazz',
    'Soundtrack': None,
    'International': None,
    'Old-Time': None
}


# Helper functions to read fused, mel, and chromagram
def read_fused_spectrogram(spectrogram_file):
    spectrogram = np.load(spectrogram_file)
    return spectrogram.T


def read_mel_spectrogram(spectrogram_file):
    spectrogram = np.load(spectrogram_file)[:128]
    return spectrogram.T

    
def read_chromagram(spectrogram_file):
    spectrogram = np.load(spectrogram_file)[128:]
    return spectrogram.T


# In[5]:


# TODO: It's useful to set the seed when debugging but when experimenting ALWAYS set seed=None. Why?
#For experimenting seed gives us always the same split in train,val (or test) sets of the data.
#We should never use seed to train and optimize our NN because we are working with a specific split and not random and thus optimizing
#on the specific problem (split) we made. This will have as result bad generalization of our model!
def torch_train_val_split(dataset, batch_train, batch_eval,val_size=.2,test_size=.0, shuffle=True, seed=None,overfitt_test=False):
    # Creating data indices for training and validation splits:
    dataset_size = len(dataset)
    if overfitt_test:
        dataset_size = 30
    
    #Get indexes for whole dataset
    indices = list(range(dataset_size))
    #Get number of indexes corresponding for validation set size
    val_split = int(np.floor(val_size * dataset_size))
    if test_size>0:
        #Get number of indexes corresponding for test set size (only for multitask problem and if test_size>0)
        test_split=int(np.floor(test_size * dataset_size))
    
    #Shuffle all the above indexes
    if shuffle:
        np.random.seed(seed)
        np.random.shuffle(indices)
    #Get corresponding number of indices for validation set from the random shuffle
    train_indices = indices[val_split:]
    #Get corresponding number of indices (the rest of them) for train set from the random shuffle
    val_indices = indices[:val_split]
    
    if test_size>0:
        #Special case, get corresponding number of indices for train,validation and test set from the random shuffle
        train_indices = indices[test_split+val_split:]
        val_indices = indices[test_split:test_split+val_split]
        test_indices = indices[:test_split]

        
    # Creating PT data samplers and loaders:
    train_sampler = SubsetRandomSampler(train_indices)
    val_sampler = SubsetRandomSampler(val_indices)
    if test_size>0:
        test_sampler = SubsetRandomSampler(test_indices)
    
    #Creating Dataloaders for each set 
    
    train_loader = DataLoader(dataset,
                              batch_size=batch_train,
                              sampler=train_sampler)
    val_loader = DataLoader(dataset,
                            batch_size=batch_eval,
                            sampler=val_sampler)
    
    if test_size>0:    
        test_loader = DataLoader(dataset,
                            batch_size=batch_eval,
                            sampler=test_sampler)
        
        return train_loader, val_loader,test_loader
    else:
        return train_loader, val_loader


class LabelTransformer(LabelEncoder):
    def inverse(self, y):
        try:
            return super(LabelTransformer, self).inverse_transform(y)
        except:
            return super(LabelTransformer, self).inverse_transform([y])

    def transform(self, y):
        try:
            return super(LabelTransformer, self).transform(y)
        except:
            return super(LabelTransformer, self).transform([y])


# TODO: Comment on why padding is needed (done in report)
class PaddingTransform(object):
    def __init__(self, max_length, padding_value=0):
        self.max_length = max_length
        self.padding_value = padding_value

    def __call__(self, s):
        if len(s) == self.max_length:
            return s

        if len(s) > self.max_length:
            return s[:self.max_length]

        if len(s) < self.max_length:
            s1 = copy.deepcopy(s)
            pad = np.zeros((self.max_length - s.shape[0], s.shape[1]), dtype=np.float32)
            s1 = np.vstack((s1, pad))
            return s1

# Pytorch Dataset Class for creating the dataset
class SpectrogramDataset(Dataset):
    def __init__(self, path, class_mapping=None, train=True, max_length=-1, read_spec_fn=read_fused_spectrogram,multi=(False,1),size=(1,1)):
        t = 'train' if train else 'test'
        p = os.path.join(path, t)
        self.index = os.path.join(path, "{}_labels.txt".format(t))
        self.files, labels = self.get_files_labels(self.index, class_mapping,multi)
        self.feats = [read_spec_fn(os.path.join(p, f)) for f in self.files]
        
        if size!=(1,1):
            tmp_list=[]            
            for f in self.feats:
                size_0=f.shape[0]
                target = np.zeros(size)
                target[:size_0,:]=f
                tmp_list.append(target)
            
            self.feats = tmp_list
        
        self.feat_dim = self.feats[0].shape[1]
        self.lengths = [len(i) for i in self.feats]
        self.max_length = max(self.lengths) if max_length <= 0 else max_length
        self.zero_pad_and_stack = PaddingTransform(self.max_length)
        self.label_transformer = LabelTransformer()
        if multi[0]:
            self.labels=np.array(labels)    
        else:
            if isinstance(labels, (list, tuple)):
                self.labels = np.array(self.label_transformer.fit_transform(labels)).astype('int64')

    def get_files_labels(self, txt, class_mapping,multi):
        with open(txt, 'r') as fd:
            if multi[0]:
                lines = [l.rstrip().split('\t')[0].split(',') for l in fd.readlines()[1:]]
            else:
                lines = [l.rstrip().split('\t') for l in fd.readlines()[1:]]
        files, labels = [], []

        for l in lines:
            label = l[multi[1]]
            if multi[1]==4:
                label = [l[1],l[2],l[3]]    
            if class_mapping:
                label = class_mapping[l[1]]
            if not label:
                continue
            # Kaggle automatically unzips the npy.gz format so this hack is needed
            _id = l[0].split('.')[0]
            npy_file = '{}.fused.full.npy'.format(_id)
            files.append(npy_file)
            labels.append(label)
        return files, labels

    def __getitem__(self, item):
        l = min(self.lengths[item], self.max_length)
        return self.zero_pad_and_stack(self.feats[item]), self.labels[item], l

    def __len__(self):
        return len(self.labels)


# In[16]:


class BasicLSTM(nn.Module):
    def __init__(self, input_dim, rnn_size, output_dim, num_layers, bidirectional=False,dropout = 0):
        super(BasicLSTM, self).__init__()
        self.bidirectional = bidirectional
        self.feature_size = rnn_size * 2 if self.bidirectional else rnn_size
        self.layers = num_layers
        self.hidden_size = rnn_size
        device=DEVICE
        self.lstm = nn.LSTM(input_size=input_dim,hidden_size=rnn_size,num_layers=num_layers,dropout=dropout,bidirectional=bidirectional,batch_first=True).to(device)
        
        
        self.clf = nn.Linear(in_features=self.feature_size,out_features=output_dim).to(device)
        # --------------- Insert your code here ---------------- #
        # Initialize the LSTM, Dropout, Output layers
    def forward(self, x, lengths):
        """
            x : 3D numpy array of dimension N x L x D
                N: batch index
                L: sequence index
                D: feature index
            lengths: N x 1
         """
        self.DEVICE = 'cuda' if torch.cuda.is_available() else 'cpu'
        DEVICE = self.DEVICE

        # Initial Hidden State h_0
        if self.bidirectional:
            h_0 = torch.zeros(self.layers*2,len(x),self.hidden_size).to(DEVICE).double()
            # Initial Cell State c_0 (same as h_0)
            c_0 = torch.zeros(self.layers*2,len(x),self.hidden_size).to(DEVICE).double()
        else:
            h_0 = torch.zeros(self.layers,len(x),self.hidden_size).to(DEVICE).double()
            # Initial Cell State c_0 (same as h_0)
            c_0 = torch.zeros(self.layers,len(x),self.hidden_size).to(DEVICE).double()
        
        lstm_out,_ = self.lstm(x.double(),(h_0,c_0))
        last_outputs = self.clf(self.last_timestep(lstm_out,lengths,bidirectional=self.bidirectional))
        
        return last_outputs
    
    def last_timestep(self, outputs, lengths, bidirectional=False):
        """
            Returns the last output of the LSTM taking into account the zero padding
        """
        if bidirectional:
            forward, backward = self.split_directions(outputs)
            last_forward = self.last_by_index(forward, lengths)
            last_backward = backward[:, 0, :]
            # Concatenate and return - maybe add more functionalities like average
            return torch.cat((last_forward, last_backward), dim=-1)
        else:
            return self.last_by_index(outputs, lengths)
    @staticmethod
    def split_directions(outputs):
        direction_size = int(outputs.size(-1) / 2)
        forward = outputs[:, :, :direction_size]
        backward = outputs[:, :, direction_size:]
        return forward, backward
    @staticmethod
    def last_by_index(outputs, lengths):
        # Index of the last output for each sequence.
        idx = (lengths - 1).view(-1, 1).expand(outputs.size(0),
                                               outputs.size(2)).unsqueeze(1)
        return outputs.gather(1, idx.long()).squeeze()


# In[10]:


from torch.optim import SGD,Adam,SparseAdam,ASGD
from time import time 
import copy
def fit_lstm(model,epochs,lr,t_loader,v_loader,val=True,DEVICE=torch.device('cpu')):
    # Create model and convert to a cuda compatible oject
    model = model.double().to(DEVICE)
    
    to_print=1
    if epochs>100:
        to_print=50
    if epochs>700:
        to_print=100
    
    val_losses = []
    train_losses = []

    # Initialization of loss function and optimizer 
    loss_fun = nn.CrossEntropyLoss()
    optimizer = Adam(model.parameters(),lr=lr)

    for epoch in range(epochs):
        ep_loss = 0             
        # Iterate over batches of the Train Dataset
        model.train()

        for batch in t_loader:
            X,labels,lengths=batch
#             model.zero_grad()
            optimizer.zero_grad()

            out = model(X.to(DEVICE),lengths.to(DEVICE)).to(DEVICE)

            loss = loss_fun(out,labels.to(DEVICE))
            loss.backward()

            optimizer.step()

            ep_loss += loss.data.item()

        train_losses.append(ep_loss/len(t_loader))

        if epoch%to_print == 0:
            print(f'Epoch {epoch+1} : Train loss is {ep_loss/len(t_loader)}')

        model.eval()

        if val :
            with torch.no_grad():
                validation_loss = 0 
                # Iterate over validation set in batches, to check to validation loss
                for i,batch in enumerate(v_loader) :
                    X,labels,lengths=batch

                    out_val = model(X.to(device),lengths.to(device)).to(DEVICE)

                    loss  = loss_fun(out_val.to(DEVICE),labels.to(DEVICE))

                    validation_loss+=loss.data.item()

                val_losses.append(validation_loss/len(v_loader))
                
                if epoch%to_print == 0:
                    print(f'Epoch {epoch+1} : Validation Loss is {validation_loss/len(v_loader)}')
                    print('-'*80)
                    
    if val:
        return model ,train_losses,val_losses
    else :
        return model,train_losses


# In[11]:


# Definition of a function that calculates the accuracy of a model 
def score_lstm(model,loader,DEVICE=torch.device('cpu')) :
    preds = []
    y_test = []
    for i,batch in enumerate(loader,1) :
        X,labels,lengths=batch        
        X.to(DEVICE)
        with torch.no_grad():
            
            out = model(X.to(DEVICE).double(),lengths.to(DEVICE)).to(DEVICE)
        if X.size()[0] !=1 :
            for y_pred,label in zip(out,labels) :
                tmp = torch.argmax(y_pred)
                preds.append(tmp.item())
                y_test.append(label)
        else :
            y_pred = torch.argmax(out).item()
            preds.append(y_pred)
            y_test.append(labels)
    return accuracy_score(preds,y_test),np.array(preds),np.array(y_test)


# ### Βήμα 7

# In[10]:


mel_specs = SpectrogramDataset(
         '../input/patreco3-multitask-affective-music/data/fma_genre_spectrograms/',
         train=True,
         class_mapping=class_mapping,
         max_length=-1,
         read_spec_fn=read_mel_spectrogram)
    
train_loader_mel , val_loader_mel = torch_train_val_split(mel_specs, 32 ,32, val_size=.20)
     
ttest_loader_mel = SpectrogramDataset(
         '../input/patreco3-multitask-affective-music/data/fma_genre_spectrograms/',
         train=False,
         class_mapping=class_mapping,
         max_length=-1,
         read_spec_fn=read_mel_spectrogram)

test_loader_mel, _ = torch_train_val_split(ttest_loader_mel, 32 ,32, val_size=0)

#Small Dataloader for training until overfitt to check that our NN works properly
train_loader_mel_overfitt, _ = torch_train_val_split(mel_specs, 32 ,32, val_size=0.99)


# In[6]:


class Net(Module):   
    def __init__(self,lin_inp=2560,lin_out=10):
        super(Net, self).__init__()

        self.cnn_layers = Sequential(
            # Defining a 2D convolution layer
            Conv2d(1, 64, kernel_size=3),
            BatchNorm2d(64),
            ReLU(inplace=True),
            MaxPool2d(kernel_size=2),
            # Defining another 2D convolution layer
            Conv2d(64, 32, kernel_size=3),
            BatchNorm2d(32),
            ReLU(inplace=True),
            MaxPool2d(kernel_size=2),
            # Defining another 2D convolution layer
            Conv2d(32, 16, kernel_size=3),
            BatchNorm2d(16),
            ReLU(inplace=True),
            MaxPool2d(kernel_size=2),
            # Defining another 2D convolution layer
            Conv2d(16, 8, kernel_size=3),
            BatchNorm2d(8),
            ReLU(inplace=True),
            MaxPool2d(kernel_size=2),
#             Dropout2d(0.2),
        )
        
        self.linear_layers = Sequential(
            Dropout(0.2),
            Linear(lin_inp,64),
            Linear(64,lin_out)
        )

        
    # Defining the forward pass    
    def forward(self, x):
        x = x.view(x.size(0), 1, x.size(1), x.size(2)).to(DEVICE) 
        x = x.double().to(DEVICE)
        x = self.cnn_layers(x)
        x = x.view(x.size(0), -1)
#         print(x.size())
        x = self.linear_layers(x)
        return x


# In[7]:


def fit_cnn(model,epochs,lr,t_loader,v_loader,val=True,DEVICE=torch.device('cpu')):
    # Create model and convert to a cuda compatible oject
    model = model.double().to(DEVICE)

    val_losses = []
    train_losses = []

    # Initialization of loss function and optimizer 
    loss_fun = nn.CrossEntropyLoss()
    optimizer = SGD(model.parameters(),lr=lr,weight_decay=0.0001)

    for epoch in range(epochs):
        ep_loss = 0             
        # Iterate over batches of the Train Dataset
        model.train()

        for batch in t_loader:
            X,labels,lengths=batch

            optimizer.zero_grad()
                
            out = model(X.to(DEVICE).double()).to(DEVICE)

            loss = loss_fun(out.to(DEVICE),labels.to(DEVICE))

            loss.backward()

            optimizer.step()

            ep_loss += loss.data.item()

        train_losses.append(ep_loss/len(t_loader))
        
        score,_,_=score_cnn(model,t_loader,DEVICE)
        print(f'Epoch {epoch+1} : Train loss is {np.round(ep_loss/len(t_loader),4)} with score: {np.round(score,3)}')

        model.eval()

        if val :
            with torch.no_grad():
                validation_loss = 0 
                # Iterate over validation set in batches, to check to validation loss
                for i,batch in enumerate(v_loader) :
                    X,labels,lengths=batch

                    out_val = model(X.double()).to(DEVICE)

                    loss  = loss_fun(out_val.to(DEVICE),labels.to(DEVICE))

                    validation_loss+=loss.data.item()

                val_losses.append(validation_loss/len(v_loader))
                score,_,_=score_cnn(model,v_loader,DEVICE)
                print(f'Epoch {epoch+1} : Validation Loss is {np.round(validation_loss/len(v_loader),4)} with score: {np.round(score,3)}')
                    
    if val:
        return model ,train_losses,val_losses
    else :
        return model,train_losses


# In[8]:


# Definition of a function that calculates the accuracy of a model 
def score_cnn(model,loader,DEVICE=torch.device('cpu')) :
    preds = []
    y_test = []
    for i,batch in enumerate(loader,1) :
        X,labels,lengths=batch
        X.to(DEVICE)
        with torch.no_grad():
            
            out = model(X.double())
        if X.size()[0] !=1 :
            for y_pred,label in zip(out,labels) :
                tmp = torch.argmax(y_pred)
                preds.append(tmp.item())
                y_test.append(label)
        else :
            y_pred = torch.argmax(out).item()
            preds.append(y_pred)
            y_test.append(labels)
    return accuracy_score(preds,y_test),np.array(preds),np.array(y_test)


# In[11]:


start=time()
model_overfitt_cnn=Net(3744)
model_trainned ,losses= fit_cnn(model_overfitt_cnn,20,0.01,train_loader_mel_overfitt,None,DEVICE=DEVICE,val=False)
print(f"Model (CNN) trained in :{np.round(time()-start,3)}")


# In[12]:


print(f"Overfitt proof is :{score_cnn(model_overfitt_cnn,train_loader_mel_overfitt,DEVICE)}")


# In[15]:


start=time()
model_cnn=Net(3744)
model_trainned ,losses,val_losses= fit_cnn(model_cnn,40,0.0005,train_loader_mel,val_loader_mel,DEVICE=DEVICE,val=True)
print(f"Model (CNN) trained in :{np.round(time()-start,3)}")


# In[16]:


score,y_test_pred,y_test=score_cnn(model_trainned,test_loader_mel,DEVICE)
print(f"FMA spectrogramms score with CNN is :{score} \n")
print(classification_report(y_test, y_test_pred))


# ## Βήμα 8

# Έχουμε προσθέσει μια παράμετρο στην δοθείσα συνάρτηση,ένα tuple του οποίου αν η πρώτη παράμετρος είναι αληθής σημαίνει οτι εξετάζουμε την περίπτωση του multitask_dataset. Στην συνέχεια με τιμή index 1,2,3,4 αντίστοιχα του ζητάμε να θεωρήσει ως labels τις τιμές valence,energy,dancability και valence-energy-dancability αντίστοιχα.
# 
# Έχουμε επιπλέον αλλάξει και την torch_train_val_split προσθέτωντας την παράμετρο test_size ή οποία αν δεν είναι μηδενική τότε επιστρέφει 3 σύνολα (αντί των 2) train,validation και test (με αντίστοιχα ποσοστά που ορίζουμε). Έχουμε ορίσει επιπλέον μια τιμή bool overfitt_test (default==False) όπου αν δωθεί ως True επιστρέφει ενα πολύ μικρό σύνολο (για κάθε ένα απο τα σετ) για να δοκιμάσουμε ότι το μοντέλο μας κάνει overfitt στην διάκεια πολλών εποχών και συνεπώς λειτουργεί.

# In[10]:


valence_multi_specs = SpectrogramDataset(
         '../input/patreco3-multitask-affective-music/data/multitask_dataset/',
         train=True,
         max_length=-1,
         read_spec_fn=read_mel_spectrogram,multi=(True,1))
    
train_loader_valence_multi, val_loader_valence_multi,test_loader_valence_multi = torch_train_val_split(valence_multi_specs, 32 ,32, val_size=0.24,test_size=0.21)

energy_multi_specs = SpectrogramDataset(
         '../input/patreco3-multitask-affective-music/data/multitask_dataset/',
         train=True,
         max_length=-1,
         read_spec_fn=read_mel_spectrogram,multi=(True,2))
    
train_loader_energy_multi, val_loader_energy_multi,test_loader_energy_multi = torch_train_val_split(energy_multi_specs, 32 ,32, val_size=0.24,test_size=0.21)
     
danceability_multi_specs = SpectrogramDataset(
         '../input/patreco3-multitask-affective-music/data/multitask_dataset/',
         train=True,
         max_length=-1,
         read_spec_fn=read_mel_spectrogram,multi=(True,3))
    
train_loader_danceability_multi, val_loader_danceability_multi,test_loader_danceability_multi = torch_train_val_split(danceability_multi_specs, 32 ,32, val_size=0.24,test_size=0.21)


train_loader_valence_multi_overfitt,_,_ = torch_train_val_split(valence_multi_specs, 32 ,32, val_size=0.24,test_size=0.21,overfitt_test=True)


# In[11]:


def fit_reg(model,epochs,lr,t_loader,v_loader,val=True,lstm=False,DEVICE=torch.device('cpu')):
    # Create model and convert to a cuda compatible oject
    model = model.double().to(DEVICE)

    val_losses = []
    train_losses = []

    to_print=1
    if epochs>100:
        to_print=50
    if epochs>700:
        to_print=100
    
    # Initialization of loss function and optimizer 
    loss_fun = nn.MSELoss()
    optimizer = Adam(model.parameters(),lr=lr)

    for epoch in range(epochs):
        ep_loss = 0             
        # Iterate over batches of the Train Dataset
        model.train()

        for batch in t_loader:
            X,labels,lengths=batch

            labels=np.array(labels).astype("float64")

            labels=torch.tensor(labels)
            
            optimizer.zero_grad()

            if lstm:
                out = model(X.to(DEVICE).double(),lengths.to(DEVICE).double()).to(DEVICE)
            else:
                out = model(X.to(DEVICE).double()).to(DEVICE)
                        
            out=out.view(out.size()[0],)
        
            loss = loss_fun(out.to(DEVICE).double(),labels.to(DEVICE).double())
            
            loss.backward()

            optimizer.step()

            ep_loss += loss.data.item()

        train_losses.append(ep_loss/len(t_loader))

        if epoch%to_print == 0:
            print(f'Epoch {epoch} : Train loss is {ep_loss/len(t_loader)}')

        model.eval()

        if val :
            with torch.no_grad():
                validation_loss = 0 
                # Iterate over validation set in batches, to check to validation loss
                for i,batch in enumerate(v_loader) :
                    X,labels,lengths=batch

                    labels=np.array(labels).astype("float64")

                    labels=torch.tensor(labels)
                    
                    if lstm:
                        out_val = model(X.to(DEVICE).double(),lengths.to(DEVICE).double()).to(DEVICE)
                    else:
                        out_val = model(X.to(DEVICE).double()).to(DEVICE)

                    out_val=out_val.view(out_val.size()[0],)

                    loss  = loss_fun(out_val.to(DEVICE),labels.to(DEVICE))

                    validation_loss+=loss.data.item()

                val_losses.append(validation_loss/len(v_loader))

                if epoch%to_print == 0:
                    print(f'Epoch {epoch} : Validation Loss is {validation_loss/len(v_loader)}')
                    print('-'*80)
                                        
    if val:
        return model ,train_losses,val_losses
    else :
        return model,train_losses


# In[12]:


def score_reg(model,loader,lstm=False,DEVICE=torch.device('cpu')) :
    preds = []
    y_test = []
    for i,batch in enumerate(loader,1) :
        X,labels,lengths=batch
        X.to(DEVICE)
        
        labels=np.array(labels).astype("float64")
        labels=torch.tensor(labels)
        
        with torch.no_grad():
            
            if lstm:
                out = model(X.to(DEVICE).double(),lengths.to(DEVICE))
            else:
                out = model(X.double())
        y_test.extend(np.array(labels.to('cpu')))
        preds.extend(np.array(out.to('cpu')))
    return np.array(y_test),np.array(preds),


# In[23]:


model=Net(3744,1)
model_trainned ,_= fit_reg(model,190,0.001,train_loader_valence_multi_overfitt, None,val=False,DEVICE=DEVICE)


# In[24]:


y_test,out=score_reg(model_trainned,train_loader_valence_multi_overfitt,DEVICE=DEVICE)
spearmanr(y_test,out)


# In[42]:


model=BasicLSTM(128, 32, 1, 1, bidirectional=True)
model_trainned ,_= fit_reg(model,1500,0.001,train_loader_valence_multi_overfitt, None,val=False,lstm=True,DEVICE=DEVICE)


# In[43]:


y_test,out=score_reg(model_trainned,train_loader_valence_multi_overfitt,lstm=True,DEVICE=DEVICE)
spearmanr(y_test,out)


# Συνεπώς τα μοντέλο μας πράγματι κάνουν overfitt στο πρόβλημα regression οπως επιθυμούσαμε.

# Απο ερώτημα 5 πήραμε τα καλύτερα αποτελέσματα για την mel beat είσοδo.

# In[15]:


valence_multi_melbeat = SpectrogramDataset(
         '../input/patreco3-multitask-affective-music/data/multitask_dataset/',
         train=True,
         max_length=-1,
         read_spec_fn=read_mel_spectrogram,multi=(True,1))
    
train_loader_valence_multi_melbeat, val_loader_valence_multi_melbeat,test_loader_valence_multi_melbeat = torch_train_val_split(valence_multi_melbeat, 32 ,32, val_size=0.24,test_size=0.21)

energy_multi_melbeat = SpectrogramDataset(
         '../input/patreco3-multitask-affective-music/data/multitask_dataset/',
         train=True,
         max_length=-1,
         read_spec_fn=read_mel_spectrogram,multi=(True,2))
    
train_loader_energy_multi_melbeat, val_loader_energy_multi_melbeat,test_loader_energy_multi_melbeat = torch_train_val_split(energy_multi_melbeat, 32 ,32, val_size=0.24,test_size=0.21)
     
danceability_multi_melbeat = SpectrogramDataset(
         '../input/patreco3-multitask-affective-music/data/multitask_dataset/',
         train=True,
         max_length=-1,
         read_spec_fn=read_mel_spectrogram,multi=(True,3))
    
train_loader_danceability_multi_melbeat, val_loader_danceability_multi_melbeat,test_loader_danceability_multi_melbeat = torch_train_val_split(danceability_multi_melbeat, 32 ,32, val_size=0.24,test_size=0.21)


# ### Valence

# In[46]:


model=BasicLSTM(128, 64, 1, 2, bidirectional=True)
model_trainned ,_,_= fit_reg(model,200,0.001,train_loader_valence_multi_melbeat, val_loader_valence_multi_melbeat,val=True,lstm=True,DEVICE=DEVICE)


# In[47]:


y_test,out=score_reg(model_trainned,test_loader_valence_multi_melbeat,lstm=True,DEVICE=DEVICE)
print(f"LSTM Spearman score for valence estimation is : {spearmanr(y_test,out)}")


# In[32]:


model=Net(3744,1)
model_trainned ,losses,val_losses= fit_reg(model,30,0.001,train_loader_valence_multi, val_loader_valence_multi,DEVICE=DEVICE)


# In[33]:


y_test,out=score_reg(model_trainned,test_loader_valence_multi,lstm=False,DEVICE=DEVICE)
print(f"CNN Spearman score for valence estimation is : {spearmanr(y_test,out)}")


# ### Energy

# In[48]:


model=BasicLSTM(128, 32, 1, 1, bidirectional=True)
model_trainned ,_,_= fit_reg(model,200,0.001,train_loader_energy_multi_melbeat, val_loader_energy_multi_melbeat,val=True,lstm=True,DEVICE=DEVICE)


# In[35]:


y_test,out=score_reg(model_trainned,test_loader_energy_multi_melbeat,lstm=True,DEVICE=DEVICE)
print(f"LSTM Spearman score for energy estimation is : {spearmanr(y_test,out)}")


# In[36]:


model=Net(3744,1)
model_trainned ,losses,val_losses= fit_reg(model,30,0.001,train_loader_energy_multi, val_loader_energy_multi,DEVICE=DEVICE)


# In[37]:


y_test,out=score_reg(model_trainned,test_loader_energy_multi,lstm=False,DEVICE=DEVICE)
print(f"CNN Spearman score for energy estimation is : {spearmanr(y_test,out)}")


# ### Danceability

# In[49]:


model=BasicLSTM(128, 32, 1, 1, bidirectional=True)
model_trainned ,_,_= fit_reg(model,200,0.001,train_loader_danceability_multi_melbeat, val_loader_danceability_multi_melbeat,val=True,lstm=True,DEVICE=DEVICE)


# In[50]:


y_test,out=score_reg(model_trainned,test_loader_danceability_multi_melbeat,lstm=True,DEVICE=DEVICE)
print(f"LSTM Spearman score for danceability estimation is : {spearmanr(y_test,out)}")


# In[38]:


model=Net(3744,1)
model_trainned ,losses,val_losses= fit_reg(model,30,0.001,train_loader_danceability_multi, val_loader_danceability_multi,DEVICE=DEVICE)


# In[39]:


y_test,out=score_reg(model_trainned,test_loader_danceability_multi,lstm=False,DEVICE=DEVICE)
print(f"CNN Spearman score for danceability estimation is : {spearmanr(y_test,out)}")

