#!/usr/bin/env python
# coding: utf-8

# In[1]:


# This Python 3 environment comes with many helpful analytics libraries installed
# It is defined by the kaggle/python Docker image: https://github.com/kaggle/docker-python
# For example, here's several helpful packages to load

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)

# Input data files are available in the read-only "../input/" directory
# For example, running this (by clicking run or pressing Shift+Enter) will list all files under the input directory

import os
for dirname, _, filenames in os.walk('/kaggle/input'):
    for filename in filenames:
        print(os.path.join(dirname, filename))

# You can write up to 20GB to the current directory (/kaggle/working/) that gets preserved as output when you create a version using "Save & Run All" 
# You can also write temporary files to /kaggle/temp/, but they won't be saved outside of the current session


# In[2]:


# Import the necessary libraries

import numpy as np
import copy
from sklearn.preprocessing import LabelEncoder
from imblearn.over_sampling import RandomOverSampler
from torch.utils.data import Dataset
from torch.utils.data import SubsetRandomSampler, DataLoader
from sklearn.decomposition import PCA
import re

# Combine similar classes and remove underrepresented classes
class_mapping = {
    'Rock': 'Rock',
    'Psych-Rock': 'Rock',
    'Indie-Rock': None,
    'Post-Rock': 'Rock',
    'Psych-Folk': 'Folk',
    'Folk': 'Folk',
    'Metal': 'Metal',
    'Punk': 'Metal',
    'Post-Punk': None,
    'Trip-Hop': 'Trip-Hop',
    'Pop': 'Pop',
    'Electronic': 'Electronic',
    'Hip-Hop': 'Hip-Hop',
    'Classical': 'Classical',
    'Blues': 'Blues',
    'Chiptune': 'Electronic',
    'Jazz': 'Jazz',
    'Soundtrack': None,
    'International': None,
    'Old-Time': None
}


# Helper functions to read fused, mel, and chromagram
def read_fused_spectrogram(spectrogram_file):
    spectrogram = np.load(spectrogram_file)
    return spectrogram.T


def read_mel_spectrogram(spectrogram_file):
    spectrogram = np.load(spectrogram_file)[:128]
    return spectrogram.T

    
def read_chromagram(spectrogram_file):
    spectrogram = np.load(spectrogram_file)[128:]
    print(spectrogram.shape)
    return spectrogram.T


# In[3]:



# Define a function that splits a dataset in train and validation set.

def torch_train_val_split(dataset, batch_train, batch_eval, val_size=.2, shuffle=True, seed=None):
    # Creating data indices for training and validation splits:
    dataset_size = len(dataset)
    indices = list(range(dataset_size))
    val_split = int(np.floor(val_size * dataset_size))
    if shuffle:
        np.random.seed(seed)
        np.random.shuffle(indices)
    # Rearrange train and validation set
    train_indices = indices[val_split:]
    val_indices = indices[:val_split]

    # Creating PT data samplers and loaders:
    train_sampler = SubsetRandomSampler(train_indices)
    val_sampler = SubsetRandomSampler(val_indices)

    train_loader = DataLoader(dataset,
                              batch_size=batch_train,
                              sampler=train_sampler)
    val_loader = DataLoader(dataset,
                            batch_size=batch_eval,
                            sampler=val_sampler)
    return train_loader, val_loader



# Define an encoder for the labels

class LabelTransformer(LabelEncoder):
    def inverse(self, y):
        try:
            return super(LabelTransformer, self).inverse_transform(y)
        except:
            return super(LabelTransformer, self).inverse_transform([y])

    def transform(self, y):
        try:
            return super(LabelTransformer, self).transform(y)
        except:
            return super(LabelTransformer, self).transform([y])




# TODO: Comment on why padding is needed
class PaddingTransform(object):
    def __init__(self, max_length, padding_value=0):
        self.max_length = max_length
        self.padding_value = padding_value

    def __call__(self, s):
        if len(s) == self.max_length:
            return s

        if len(s) > self.max_length:
            return s[:self.max_length]

        if len(s) < self.max_length:
            s1 = copy.deepcopy(s)
            pad = np.zeros((self.max_length - s.shape[0], s.shape[1]), dtype=np.float32)
            s1 = np.vstack((s1, pad))
            return s1

# Pytorch Dataset Class for creating the dataset


class SpectrogramDataset(Dataset):
    def __init__(self, path, class_mapping=None, train=True, max_length=-1, read_spec_fn=read_fused_spectrogram):
        t = 'train' if train else 'test'
        p = os.path.join(path, t)
        self.index = os.path.join(path, "{}_labels.txt".format(t))
        self.files, labels = self.get_files_labels(self.index, class_mapping)
        self.feats = [read_spec_fn(os.path.join(p, f)) for f in self.files]
        self.feat_dim = self.feats[0].shape[1]
        self.lengths = [len(i) for i in self.feats]
        self.max_length = max(self.lengths) if max_length <= 0 else max_length
        self.zero_pad_and_stack = PaddingTransform(self.max_length)
        self.label_transformer = LabelTransformer()
        if isinstance(labels, (list, tuple)):
            self.labels = np.array(self.label_transformer.fit_transform(labels)).astype('int64')

    def get_files_labels(self, txt, class_mapping):
        with open(txt, 'r') as fd:
            lines = [l.rstrip().split('\t') for l in fd.readlines()[1:]]
        files, labels = [], []
        for l in lines:
            label = l[1]
            if class_mapping:
                label = class_mapping[l[1]]
            if not label:
                continue
            # Kaggle automatically unzips the npy.gz format so this hack is needed
            _id = l[0].split('.')[0]
            npy_file = '{}.fused.full.npy'.format(_id)
            files.append(npy_file)
            labels.append(label)
        return files, labels
    

    def __getitem__(self, item):
        # Return a tuple in the form (padded_feats, label, length)
        l = min(self.lengths[item], self.max_length)
        return self.zero_pad_and_stack(self.feats[item]), self.labels[item], l

    def __len__(self):
        return len(self.labels)


# In[6]:


specs_fused = SpectrogramDataset(
         '../input/patreco3-multitask-affective-music/data/fma_genre_spectrograms/',
         train=True,
         class_mapping=class_mapping,
         max_length=-1,
         read_spec_fn=read_fused_spectrogram)

train_loader, val_loader = torch_train_val_split(specs_fused, 32 ,32, val_size=.33)

ttest_loader = SpectrogramDataset(
     '../input/patreco3-multitask-affective-music/data/fma_genre_spectrograms/',
     train=False,
     class_mapping=class_mapping,
     max_length=-1,
     read_spec_fn=read_fused_spectrogram)
test_loader = DataLoader(ttest_loader,batch_size=32)


# In[7]:


datum = next(iter(train_loader))
print('Data shape')
print(datum[0].shape)  # shape of data
print('Labels')
print(datum[1])  # labels in batch
print('Lengths')
print(datum[2])  # length of each element in batch


# # Βήμα 9α

# In[4]:


# Redifine given functions in order to fit our data properties

def torch_train_val_split(dataset, batch_train, batch_eval,val_size=.2,test_size=.0, shuffle=True, seed=None,overfitt_test=False):
    # Creating data indices for training and validation splits:
    dataset_size = len(dataset)
    if overfitt_test:
        dataset_size = 30
    
    indices = list(range(dataset_size))
    val_split = int(np.floor(val_size * dataset_size))
    if test_size>0:
        test_split=int(np.floor(test_size * dataset_size))
    
    if shuffle:
        np.random.seed(seed)
        np.random.shuffle(indices)
    train_indices = indices[val_split:]
    val_indices = indices[:val_split]
    
    if test_size>0:
        train_indices = indices[test_split+val_split:]
        val_indices = indices[test_split:test_split+val_split]
        test_indices = indices[:test_split]

        
    # Creating PT data samplers and loaders:
    train_sampler = SubsetRandomSampler(train_indices)
    val_sampler = SubsetRandomSampler(val_indices)
    if test_size>0:
        test_sampler = SubsetRandomSampler(test_indices)
    

    train_loader = DataLoader(dataset,
                              batch_size=batch_train,
                              sampler=train_sampler)
    val_loader = DataLoader(dataset,
                            batch_size=batch_eval,
                            sampler=val_sampler)
    
    if test_size>0:    
        test_loader = DataLoader(dataset,
                            batch_size=batch_eval,
                            sampler=test_sampler)
        
        return train_loader, val_loader,test_loader
    else:
        return train_loader, val_loader


class LabelTransformer(LabelEncoder):
    def inverse(self, y):
        try:
            return super(LabelTransformer, self).inverse_transform(y)
        except:
            return super(LabelTransformer, self).inverse_transform([y])

    def transform(self, y):
        try:
            return super(LabelTransformer, self).transform(y)
        except:
            return super(LabelTransformer, self).transform([y])


# TODO: Comment on why padding is needed
class PaddingTransform(object):
    def __init__(self, max_length, padding_value=0):
        self.max_length = max_length
        self.padding_value = padding_value

    def __call__(self, s):
        if len(s) == self.max_length:
            return s

        if len(s) > self.max_length:
            return s[:self.max_length]

        if len(s) < self.max_length:
            s1 = copy.deepcopy(s)
            pad = np.zeros((self.max_length - s.shape[0], s.shape[1]), dtype=np.float32)
            s1 = np.vstack((s1, pad))
            return s1

# Pytorch Dataset Class for creating the dataset
class SpectrogramDataset(Dataset):
    def __init__(self, path, class_mapping=None, train=True, max_length=-1, read_spec_fn=read_fused_spectrogram,multi=(False,1)):
        t = 'train' if train else 'test'
        p = os.path.join(path, t)
        self.index = os.path.join(path, "{}_labels.txt".format(t))
        self.files, labels = self.get_files_labels(self.index, class_mapping,multi)
        self.feats = [read_spec_fn(os.path.join(p, f)) for f in self.files]
        
        if t=='test':
            tmp_list=[]            
            for f in self.feats:
                size_0=f.shape[0]
                target = np.zeros((129,128))
                target[:size_0,:]=f
                tmp_list.append(target)
            
            self.feats = tmp_list
        
        self.feat_dim = self.feats[0].shape[1]
        self.lengths = [len(i) for i in self.feats]
        self.max_length = max(self.lengths) if max_length <= 0 else max_length
        self.zero_pad_and_stack = PaddingTransform(self.max_length)
        self.label_transformer = LabelTransformer()
        if multi[0]:
            self.labels=np.array(labels)    
        else:
            if isinstance(labels, (list, tuple)):
                self.labels = np.array(self.label_transformer.fit_transform(labels)).astype('int64')

    def get_files_labels(self, txt, class_mapping,multi):
        with open(txt, 'r') as fd:
            if multi[0]:
                lines = [l.rstrip().split('\t')[0].split(',') for l in fd.readlines()[1:]]
            else:
                lines = [l.rstrip().split('\t') for l in fd.readlines()[1:]]
        files, labels = [], []

        for l in lines:
            label = l[multi[1]]
            if multi[1]==4:
                label = [l[1],l[2],l[3]]    
            if class_mapping:
                label = class_mapping[l[1]]
            if not label:
                continue
            # Kaggle automatically unzips the npy.gz format so this hack is needed
            _id = l[0].split('.')[0]
            npy_file = '{}.fused.full.npy'.format(_id)
            files.append(npy_file)
            labels.append(label)
        return files, labels

    def __getitem__(self, item):
        # TODO: Inspect output and comment on how the output is formatted
        l = min(self.lengths[item], self.max_length)
        return self.zero_pad_and_stack(self.feats[item]), self.labels[item], l

    def __len__(self):
        return len(self.labels)


# In[5]:


valence_multi_fusedbeat = SpectrogramDataset(
         '../input/patreco3-multitask-affective-music/data/multitask_dataset/',
         train=True,
         max_length=-1,
         read_spec_fn=read_fused_spectrogram,multi=(True,1))
    
train_loader_valence_multi, val_loader_valence_multi,test_loader_valence_multi = torch_train_val_split(valence_multi_fusedbeat, 32 ,32, val_size=0.24,test_size=0.21)

energy_multi_fusedbeat = SpectrogramDataset(
         '../input/patreco3-multitask-affective-music/data/multitask_dataset/',
         train=True,
         max_length=-1,
         read_spec_fn=read_fused_spectrogram,multi=(True,2))
    
train_loader_energy_multi, val_loader_energy_multi,test_loader_energy_multi = torch_train_val_split(energy_multi_fusedbeat, 32 ,32, val_size=0.24,test_size=0.21)
     
danceability_multi_fusedbeat = SpectrogramDataset(
         '../input/patreco3-multitask-affective-music/data/multitask_dataset/',
         train=True,
         max_length=-1,
         read_spec_fn=read_fused_spectrogram,multi=(True,3))
    
train_loader_dance_multi, val_loader_dance_multi,test_loader_multi = torch_train_val_split(danceability_multi_fusedbeat, 32 ,32, val_size=0.24,test_size=0.21)



# ### b)

# In[33]:


from torch.nn import *
import torch
DEVICE ='cuda' if torch.cuda.is_available() else 'cpu'
class Net(Module):   
    def __init__(self,lin_inp=2560,lin_out=10):
        super(Net, self).__init__()

        self.cnn_layers = Sequential(
            # Defining a 2D convolution layer
            Conv2d(1, 3, kernel_size=3, stride=1, padding=1),
            
            BatchNorm2d(3),
            ReLU(inplace=True),
            MaxPool2d(kernel_size=2, stride=2),
            # Defining another 2D c"onvolution layer
            Conv2d(3, 6, kernel_size=3, stride=1, padding=1),
            BatchNorm2d(6),
            ReLU(inplace=True),
            MaxPool2d(kernel_size=2, stride=2),
            # Defining another 2D convolution layer
            Conv2d(6, 4, kernel_size=3, stride=1, padding=1),
            BatchNorm2d(4),
            ReLU(inplace=True),
            MaxPool2d(kernel_size=2, stride=2),
            # Defining another 2D convolution layer
            Conv2d(4, 4, kernel_size=3, stride=1, padding=1),
            BatchNorm2d(4),
            ReLU(inplace=True),
            MaxPool2d(kernel_size=2, stride=2),
        )

        self.linear_layers = Sequential(
            Linear(lin_inp,lin_out)
        )

    # Defining the forward pass    
    def forward(self, x):
        x = x.view(x.size(0), 1, x.size(1), x.size(2)).to(DEVICE) 
        x = x.double().to(DEVICE)
        x = self.cnn_layers(x)
        x = x.view(x.size(0), -1)
        x = self.linear_layers(x)
        return x


# In[9]:


import torch
import copy 
import torch.nn as nn
from torch.optim import Adam
def fit_cnn(model,epochs,lr,t_loader,v_loader,val=True,DEVICE=torch.device('cpu')):
    # Create model and convert to a cuda compatible oject
    model = model.double().to(DEVICE)

    val_losses = []
    train_losses = []
    
    n_epochs_stop = 3
    epochs_no_improve = 0
    min_val_loss = np.Inf
        
    # Initialization of loss function and optimizer 
    loss_fun = nn.CrossEntropyLoss()
    optimizer = Adam(model.parameters(),lr=lr)

    for epoch in range(epochs):
        ep_loss = 0             
        # Iterate over batches of the Train Dataset
        model.train()

        for batch in t_loader:
            X,labels,lengths=batch
            
            optimizer.zero_grad()
                
            out = model(X.to(DEVICE).double()).to(DEVICE)

            loss = loss_fun(out.to(DEVICE),labels.long().to(DEVICE))

            loss.backward()

            optimizer.step()

            ep_loss += loss.data.item()

        train_losses.append(ep_loss/len(t_loader))

        print(f'Epoch {epoch+1} : Train loss is {ep_loss/len(t_loader)}')

        model.eval()

        if val :
            with torch.no_grad():
                validation_loss = 0 
                # Iterate over validation set in batches, to check to validation loss
                for i,batch in enumerate(v_loader) :
                    X,labels,lengths=batch
                    
                    out_val = model(X.double()).to(DEVICE)

                    loss  = loss_fun(out_val.to(DEVICE),labels.long().to(DEVICE))

                    validation_loss+=loss.data.item()

                val_losses.append(validation_loss/len(v_loader))

                print(f'Epoch {epoch+1} : Validation Loss is {validation_loss/len(v_loader)}')
                
                rounded_loss = np.round(validation_loss,decimals=3)
                if rounded_loss < min_val_loss :
                    epochs_no_improve = 0
                    min_val_loss = rounded_loss
                    best_model = copy.deepcopy(model)
                else:
                    epochs_no_improve+=1

                if epoch > 10 and epochs_no_improve>=n_epochs_stop:
                    print('Early Stopping!')
                    model = best_model 
                    print('Creating model checkpoint...')
                    torch.save(model,'./best_model_9a')
                    print('Model saved at path : ./best_model_9a')
                    break
                    
    if val:
        return model ,train_losses,val_losses
    else :
        return model,train_losses


# In[10]:


# Definition of a function that calculates the accuracy of a model 
from sklearn.metrics import accuracy_score
def score_cnn(model,loader,DEVICE=torch.device('cpu')) :
    preds = []
    y_test = []
    for i,batch in enumerate(loader,1) :
        X,labels,lengths=batch
        X.to(DEVICE)
        with torch.no_grad():
            
            out = model(X.double())
        if X.size()[0] !=1 :
            for y_pred,label in zip(out,labels) :
                tmp = torch.argmax(y_pred)
                preds.append(tmp.item())
                y_test.append(label)
        else :
            y_pred = torch.argmax(out).item()
            preds.append(y_pred)
            y_test.append(y)
    return accuracy_score(preds,y_test),np.array(preds),np.array(y_test)


# ### c)

# In[42]:


model = Net()
model, t_loss,v_loss = fit_cnn(model,epochs=200,lr=0.01,t_loader=train_loader,v_loader=val_loader,DEVICE=DEVICE)


# In[43]:


score ,preds,labels = score_cnn(model ,test_loader,DEVICE=DEVICE )
print('CNN model\'s accuracy is :',score)


# ### d)

# In[44]:


base_model = torch.load('./best_model_9a')
for param in base_model.parameters():
    param.requires_grad = False
print(model)


# In[45]:


base_model.linear_layers = nn.Linear(in_features=2560,out_features=1,bias=True)


# In[46]:


regression_transfer_model = base_model 
print(regression_transfer_model)


# Επιλέγουμε να εκπαιδεύσουμε το transfered μοντέλο μας μόνο για το task του regression ως προς το energy

# In[47]:


import torch
from torch.optim import Adam
def fit_regression(model,epochs,lr,t_loader,v_loader,val=True,DEVICE=torch.device('cpu')):
    # Create model and convert to a cuda compatible oject
    model = model.double().to(DEVICE)

    val_losses = []
    train_losses = []

    # Initialization of loss function and optimizer 
    loss_fun = nn.MSELoss()
    optimizer = Adam([{'params':regression_transfer_model.linear_layers.parameters()}],lr=lr)

    for epoch in range(epochs):
        ep_loss = 0             
        # Iterate over batches of the Train Dataset
        model.train()

        for batch in t_loader:
            X,labels,lengths=batch
#             X = X.view(X.size(0), 1, X.size(1), X.size(2))
            
            labels=np.array(labels).astype("float64")

            labels=torch.tensor(labels).view(-1,1)
            
            optimizer.zero_grad()
        
            out = model(X.to(DEVICE).double()).to(DEVICE)
                
            loss = loss_fun(out.to(DEVICE).double(),labels.to(DEVICE).double())
            
            loss.backward()

            optimizer.step()

            ep_loss += loss.data.item()

        train_losses.append(ep_loss/len(t_loader))

        print(f'Epoch {epoch+1} : Train loss is {ep_loss/len(t_loader)}')

        model.eval()

        if val :
            with torch.no_grad():
                validation_loss = 0 
                # Iterate over validation set in batches, to check to validation loss
                for i,batch in enumerate(v_loader) :
                    X,labels,lengths=batch
                    labels=np.array(labels).astype("float64")

                    labels=torch.tensor(labels).view(-1,1)
                    
                    out_val = model(X.double().to(DEVICE)).to(DEVICE)

                    loss  = loss_fun(out_val.to(DEVICE),labels.to(DEVICE))

                    validation_loss+=loss.data.item()

                val_losses.append(validation_loss/len(v_loader))

                print(f'Epoch {epoch+1} : Validation Loss is {validation_loss/len(v_loader)}')
                    
    if val:
        return model ,train_losses,val_losses
    else :
        return model,train_losses


# In[48]:


regression_transfer_model,regression_train_loss,regression_validation_loss=fit_regression(regression_transfer_model,epochs=10,lr=0.01,t_loader=train_loader_energy_multi,v_loader=val_loader_energy_multi,DEVICE=DEVICE)


# In[49]:


import torch
from scipy.stats import spearmanr
def score_reg(model,loader,lstm=False,DEVICE=torch.device('cpu')) :
    preds = []
    y_test = []
    for i,batch in enumerate(loader,1) :
        X,labels,lengths=batch
        X.to(DEVICE)
        
        labels=np.array(labels).astype("float64")
        labels=torch.tensor(labels)
        
        with torch.no_grad():
            
            if lstm:
                out = model(X.to(DEVICE).double(),lengths.to(DEVICE))
            else:
                out = model(X.double())
        y_test.extend(np.array(labels.to('cpu')))
        preds.extend(np.array(out.to('cpu')))
    return np.array(y_test),np.array(preds)


# In[50]:



y_test,out=score_reg(regression_transfer_model,test_loader_energy_multi,DEVICE=DEVICE)
print(f"CNN-Transfered Spearman score for energy estimation is : {spearmanr(y_test,out)}")


# Στην συνέχεια επιλέξαμε να δοκιμάσουμε την μέθοδο του transfer learning και με ένα μοντέλο προεκπαιδευμένο στο ImageNet.

# In[25]:


import torch
from torch.optim import Adam
# New function to trasfered model to our data 
def fit(model,epochs,lr,t_loader,v_loader,val=True,DEVICE=torch.device('cpu')):
    # Create model and convert to a cuda compatible oject
    model = model.double().to(DEVICE)

    val_losses = []
    train_losses = []

    # Initialization of loss function and optimizer 
    loss_fun = nn.MSELoss()
    optimizer = Adam([{'params':resNet.conv1.parameters()},{'params':resNet.fc.parameters()}],lr=lr)

    for epoch in range(epochs):
        ep_loss = 0             
        # Iterate over batches of the Train Dataset
        model.train()

        for batch in t_loader:
            X,labels,lengths=batch
            X = X.view(X.size(0), 1, X.size(1), X.size(2))
            
            labels=np.array(labels).astype("float64")

            labels=torch.tensor(labels).view(-1,1)
            
            optimizer.zero_grad()
        
            out = model(X.to(DEVICE).double()).to(DEVICE)
                
            loss = loss_fun(out.to(DEVICE).double(),labels.to(DEVICE).double())
            
            loss.backward()

            optimizer.step()

            ep_loss += loss.data.item()

        train_losses.append(ep_loss/len(t_loader))

        print(f'Epoch {epoch+1} : Train loss is {ep_loss/len(t_loader)}')

        model.eval()

        if val :
            with torch.no_grad():
                validation_loss = 0 
                # Iterate over validation set in batches, to check to validation loss
                for i,batch in enumerate(v_loader) :
                    X,labels,lengths=batch
                    X = X.view(X.size(0), 1, X.size(1), X.size(2))
                    labels=np.array(labels).astype("float64")

                    labels=torch.tensor(labels).view(-1,1)
                    
                    out_val = model(X.double().to(DEVICE)).to(DEVICE)

                    loss  = loss_fun(out_val.to(DEVICE),labels.to(DEVICE))

                    validation_loss+=loss.data.item()

                val_losses.append(validation_loss/len(v_loader))

                print(f'Epoch {epoch+1} : Validation Loss is {validation_loss/len(v_loader)}')
                    
    if val:
        return model ,train_losses,val_losses
    else :
        return model,train_losses


# In[5]:


import torch
from scipy.stats import spearmanr
def score_reg(model,loader,lstm=False,DEVICE=torch.device('cpu')) :
    preds = []
    y_test = []
    for i,batch in enumerate(loader,1) :
        X,labels,lengths=batch
        
        X = X.view(X.size(0), 1, X.size(1), X.size(2))
            
        labels=np.array(labels).astype("float64")

        labels=torch.tensor(labels).to(DEVICE).view(-1,1)
        X.to(DEVICE)
        with torch.no_grad():
            
            if lstm:
                out = model(X.to(DEVICE).double(),lengths.to(DEVICE))
            else:
                out = model(X.to(DEVICE).double())
        y_test.extend(np.array(labels.to('cpu')))
        preds.extend(np.array(out.to('cpu')))
    return np.array(y_test),np.array(preds)


# In[28]:


from torchvision import models 
import torch.nn as nn
resNet = models.resnet50(pretrained=True,progress=True)
for param in resNet.parameters():
    param.requires_grad = False
clf_in = resNet.fc.in_features
clf_out = 1
resNet.fc = nn.Linear(clf_in,clf_out)
resNet.conv1 = nn.Conv2d(1, 64, kernel_size=3, stride=1, padding=1)
print(resNet)


# In[29]:


model,t_loss,v_loss=fit(resNet,epochs=5,lr=0.01,t_loader=train_loader_valence_multi,v_loader=val_loader_valence_multi,DEVICE='cuda')


# In[32]:


y_test,out=score_reg(model,test_loader_valence_multi,DEVICE='cuda')
print(f"CNN-Transfered Spearman score for valence estimation is : {spearmanr(y_test,out)}")


# In[33]:


get_ipython().system('touch ./transfer_model_resnet')
torch.save(model,'./transfer_model_resnet_valence')
torch.cuda.empty_cache()


# In[34]:


from torchvision import models 
import torch.nn as nn
resNet = models.resnet50(pretrained=True,progress=True)
for param in resNet.parameters():
    param.requires_grad = False
clf_in = resNet.fc.in_features
clf_out = 1
resNet.fc = nn.Linear(clf_in,clf_out)
resNet.conv1 = nn.Conv2d(1, 64, kernel_size=3, stride=1, padding=1)
print(resNet)


# In[35]:


model,t_loss,v_loss=fit(resNet,epochs=8,lr=0.01,t_loader=train_loader_energy_multi,v_loader=val_loader_energy_multi,DEVICE='cuda')


# In[36]:


y_test,out=score_reg(model,test_loader_energy_multi,DEVICE='cuda')
print(f"CNN-Transfered Spearman score for energy estimation is : {spearmanr(y_test,out)}")


# In[37]:


get_ipython().system('touch ./transfer_model_resnet_energy')
torch.save(model,'./transfer_model_resnet_energy')
torch.cuda.empty_cache()


# In[38]:


from torchvision import models 
import torch.nn as nn
resNet = models.resnet50(pretrained=True,progress=True)
for param in resNet.parameters():
    param.requires_grad = False
clf_in = resNet.fc.in_features
clf_out = 1
resNet.fc = nn.Linear(clf_in,clf_out)
resNet.conv1 = nn.Conv2d(1, 64, kernel_size=3, stride=1, padding=1)
print(resNet)


# In[39]:


model,t_loss,v_loss=fit(resNet,epochs=5,lr=0.01,t_loader=train_loader_dance_multi,v_loader=val_loader_dance_multi,DEVICE='cuda')


# In[42]:


y_test,out=score_reg(model,test_loader_dance_multi,DEVICE='cuda')
print(f"CNN-Transfered Spearman score for danceability estimation is : {spearmanr(y_test,out)}")


# In[48]:


get_ipython().system('touch ./transfer_model_resnet_dance')
torch.save(model,'./transfer_model_resnet_dance')
torch.cuda.empty_cache()


# In[56]:





# # Βήμα 9β

# In[17]:


# Define new Dataset in order to use the input vector as whole without spliting it in valence , energy and danceability sub vectors.
class MultitaskDataset(Dataset):
    def __init__(self, path, max_length=-1, read_spec_fn=read_fused_spectrogram, label_type='energy'):
        p = os.path.join(path, 'train')
        self.label_type = label_type
        self.index = os.path.join(path, "train_labels.txt")
        self.files, labels = self.get_files_labels(self.index)
        self.feats = [read_spec_fn(os.path.join(p, f)) for f in self.files]
        self.feat_dim = self.feats[0].shape[1]
        self.lengths = [len(i) for i in self.feats]
        self.max_length = max(self.lengths) if max_length <= 0 else max_length
        self.zero_pad_and_stack = PaddingTransform(self.max_length) 
        if isinstance(labels, (list, tuple)):
            self.labels = np.array(labels)

    def get_files_labels(self, txt):
        with open(txt, 'r') as fd:
            lines = [l.split(',') for l in fd.readlines()[1:]]
        files, labels = [], []
        for l in lines:
            if self.label_type == 'valence':
                labels.append(float(l[1]))
            elif self.label_type == 'energy':
                labels.append(float(l[2]))
            elif self.label_type == 'danceability':
                labels.append(float(l[3].strip("\n")))
            else:
                labels.append([float(l[1]), float(l[2]), float(l[3].strip("\n"))])
            # Kaggle automatically unzips the npy.gz format so this hack is needed
            _id = l[0]
            npy_file = '{}.fused.full.npy'.format(_id)
            files.append(npy_file)
        return files, labels
    

    def __getitem__(self, item):
        # Return a tuple in the form (padded_feats, valence, energy, danceability, length)
        l = min(self.lengths[item], self.max_length)
        return self.zero_pad_and_stack(self.feats[item]), self.labels[item], l

    def __len__(self):
        return len(self.labels)
    


# In[27]:


specs_multi_all = MultitaskDataset(
         '../input/patreco3-multitask-affective-music/data/multitask_dataset/',
         max_length=1293,
         label_type=-1,
         read_spec_fn=read_mel_spectrogram)

train_loader_multi, val_loader_multi,test_loader_multi = torch_train_val_split(specs_multi_all, 32 ,32, val_size=0.24,test_size=0.21)


# b)

# In[28]:


import torch.nn as nn 
import torch.nn.functional as F 
# Define our multitasking CNN 
class ConvNetMultitaskLearning(nn.Module):
    def __init__(self):
        super(ConvNetMultitaskLearning, self).__init__()
        self.conv1 = nn.Conv2d(1, 3, 3)
        self.conv1_bn = nn.BatchNorm2d(3)
        self.pool1 = nn.MaxPool2d(2, 2)
        
        self.conv2 = nn.Conv2d(3, 6, 3)
        self.conv2_bn = nn.BatchNorm2d(6)
        self.pool2 = nn.MaxPool2d(2, 2)
        
        self.conv3 = nn.Conv2d(6, 8, 3)
        self.conv3_bn = nn.BatchNorm2d(8)
        self.pool3 = nn.MaxPool2d(2, 2)
        
        self.conv4 = nn.Conv2d(8, 12, 3)
        self.conv4_bn = nn.BatchNorm2d(12)
        self.pool4 = nn.MaxPool2d(2, 2)
        
        self.conv5 = nn.Conv2d(12, 16, 3)
        self.conv5_bn = nn.BatchNorm2d(16)
        self.pool5 = nn.MaxPool2d(2, 2)
                
        self.fc1 = nn.Linear(1216, 32)
        
        self.fc_val = nn.Linear(32, 1)
        
        self.fc_energy = nn.Linear(32, 1)
        
        self.fc_dance = nn.Linear(32, 1)

    def forward(self, x):
        x = x.view(x.size(0), 1, x.size(1), x.size(2))
        
        x = self.pool1(F.relu( self.conv1_bn(self.conv1(x))))
        x = self.pool2(F.relu( self.conv2_bn(self.conv2(x))))
        x = self.pool3(F.relu( self.conv3_bn(self.conv3(x))))
        x = self.pool4(F.relu( self.conv4_bn(self.conv4(x))))
        x = self.pool5(F.relu( self.conv5_bn(self.conv5(x))))
        x = x.view(x.size(0), -1)
        
        x = F.relu(self.fc1(x))
        
        energy = self.fc_energy(x)
        
        val = self.fc_val(x)
        
        dance = self.fc_dance(x)
        
        return val, energy, dance


# In[87]:


import torch
import copy 
import torch.nn as nn
from torch.optim import Adam
def fit_cnn(model,epochs,lr,t_loader,v_loader,val=True,DEVICE=torch.device('cpu')):
    # Create model and convert to a cuda compatible oject
    model = model.double().to(DEVICE)

    val_losses = []
    train_losses = []
    
    n_epochs_stop = 3
    epochs_no_improve = 0
    min_val_loss = np.Inf
        
    # Initialization of loss function and optimizer 
    loss_fun = nn.MSELoss()
    optimizer = Adam(model.parameters(),lr=lr)

    for epoch in range(epochs):
        ep_loss = 0             
        # Iterate over batches of the Train Dataset
        model.train()

        for batch in t_loader:
            X,labels,lengths=batch
            
            labels=np.array(labels).astype("float64")

            labels=torch.tensor(labels).view(-1,3)
            
            optimizer.zero_grad()
                
            out_val,out_energy,out_dance = model(X.to(DEVICE).double())

            loss_val = loss_fun(out_val.to(DEVICE).double(),labels[:,0].to(DEVICE).double())
            loss_energy = loss_fun(out_energy.to(DEVICE).double(),labels[:,1].to(DEVICE).double())
            loss_dance = loss_fun(out_dance.to(DEVICE).double(),labels[:,2].to(DEVICE).double())

            loss = loss_val+loss_energy+loss_dance

            loss.backward()

            optimizer.step()

            ep_loss += loss.data.item()

        train_losses.append(ep_loss/len(t_loader))

        print(f'Epoch {epoch+1} : Train loss is {ep_loss/len(t_loader)}')

        model.eval()

        if val :
            with torch.no_grad():
                validation_loss = 0 
                # Iterate over validation set in batches, to check to validation loss
                for i,batch in enumerate(v_loader) :
                    X,labels,lengths=batch
                    
                    labels=np.array(labels).astype("float64")
                    labels=torch.tensor(labels).view(-1,3,1)

                    out_val,out_energy,out_dance = model(X.double().to(DEVICE))

                    loss_val = loss_fun(out_val.to(DEVICE).double(),labels[:,0].to(DEVICE).double())
                    loss_energy = loss_fun(out_energy.to(DEVICE).double(),labels[:,1].to(DEVICE).double())
                    loss_dance = loss_fun(out_dance.to(DEVICE).double(),labels[:,2].to(DEVICE).double())

                    loss = loss_val+loss_energy+loss_dance

                    validation_loss+=loss.data.item()

                val_losses.append(validation_loss/len(v_loader))

                print(f'Epoch {epoch+1} : Validation Loss is {validation_loss/len(v_loader)}')
                
                rounded_loss = np.round(validation_loss,decimals=3)
                if rounded_loss < min_val_loss :
                    epochs_no_improve = 0
                    min_val_loss = rounded_loss
                    best_model = copy.deepcopy(model)
                else:
                    epochs_no_improve+=1

                if epoch > 10 and epochs_no_improve>=n_epochs_stop:
                    print('Early Stopping!')
                    model = best_model 
                    print('Creating model checkpoint...')
                    torch.save(model,'./best_model_9b')
                    print('Model saved at path : ./best_model_9b')
                    break
                    
    if val:
        return model ,train_losses,val_losses
    else :
        return model,train_losses


# In[91]:


del model 


# In[92]:


model = ConvNetMultitaskLearning()


# In[93]:


model,t_loss,val_loss=fit_cnn(model,epochs=50,lr=0.001,t_loader=train_loader_multi,v_loader=val_loader_multi,DEVICE ='cuda')


# In[94]:


import torch
from scipy.stats import spearmanr
def score_reg(model,loader,lstm=False,DEVICE=torch.device('cpu')) :
    preds_val,preds_energy,preds_dance = [],[],[]
    y_test_val,y_test_energy,y_test_dance = [],[],[]
    model.to(DEVICE)
    for i,batch in enumerate(loader,1) :
        X,labels,lengths=batch
        
        X,labels,lengths=batch
                    
        labels=np.array(labels).astype("float64")
        labels=torch.tensor(labels).view(-1,3,1)

        
        X.to(DEVICE)
        with torch.no_grad():
            
            if lstm:
                out_val,out_energy,out_dance = model(X.double().to(DEVICE),lengths)
            else:
                out_val,out_energy,out_dance = model(X.double().to(DEVICE))
        y_test_val.extend(np.array(labels[:,0].to('cpu')))
        y_test_energy.extend(np.array(labels[:,1].to('cpu')))
        y_test_dance.extend(np.array(labels[:,2].to('cpu')))
        preds_val.extend(np.array(out_val.to('cpu')))
        preds_energy.extend(np.array(out_energy.to('cpu')))
        preds_dance.extend(np.array(out_dance.to('cpu')))
    return [np.array(y_test_val),np.array(y_test_energy),np.array(y_test_dance)],[np.array(preds_val),np.array(preds_energy),np.array(preds_dance)]


# In[95]:


labels , preds = score_reg(model ,test_loader_multi)


# In[96]:


print(f"CNN-Multitask Spearman score for valence estimation is : {spearmanr(labels[0],preds[0])}")
print(f"CNN-Multitask Spearman score for energy estimation is : {spearmanr(labels[1],preds[1])}")
print(f"CNN-Multitask Spearman score for danceability estimation is : {spearmanr(labels[2],preds[2])}")

